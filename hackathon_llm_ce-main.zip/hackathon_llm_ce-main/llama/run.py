import transformers
import torch
import os

# required for running on HPC GPU 
# BATCH jobs: comment out
os.environ["CUDA_VISIBLE_DEVICES"] = "1" 
os.environ["WORLD_SIZE"] = "1"

# HF key
api_key = None # insert your HF token here
if api_key is None:
    raise ValueError("You did not provide an API key (HF token). Please insert above.")
os.environ["HF_TOKEN"] = api_key

# Model
model_id = "meta-llama/Meta-Llama-3.1-8B-Instruct"
print(f"Cuda available? {torch.cuda.is_available()}")

pipeline = transformers.pipeline(
    "text-generation",
    model=model_id,
    model_kwargs={"torch_dtype": torch.bfloat16}, 
    device_map="auto",
    max_new_tokens=4000,
    temperature=0.7,
    #device=0,
)

# Prompts
messages = [
    {"role": "system", "content": "You are an expert chemists and machine learning researcher!"},
    {"role": "user", "content": "What are current topics of interest for machine learning in chemical engineering?"},
]

messages = [
    {"role": "system", "content": "You are an expert chemists and machine learning researcher!"},
    {"role": "user", "content": "What are the products of the reaction between 2-bromo-2-methylpropane and 4-(4-hydroxyphenyl)butan-2-one?"}
]

# Get answers
outputs = pipeline(
    messages,
)
print(outputs[0]["generated_text"][-1])