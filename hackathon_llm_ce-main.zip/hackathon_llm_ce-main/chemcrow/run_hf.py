# required for running on HPC GPU 
# BATCH jobs: comment out
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1" 
os.environ["WORLD_SIZE"] = "1"

import torch

from langchain.agents import AgentExecutor, load_tools
from langchain.agents.format_scratchpad import format_log_to_str
from langchain.agents.output_parsers import (
    ReActJsonSingleInputOutputParser,
)
from langchain.tools.render import render_text_description

from langchain_huggingface.llms import HuggingFacePipeline
from langchain_huggingface import ChatHuggingFace

# Tools
from langchain_experimental.tools import PythonREPLTool
from chemcrow.tools import *

# Prompt
from prompt_hf import get_custom_prompt

#from transformers import BitsAndBytesConfig
#quantization_config = BitsAndBytesConfig(load_in_8bit=True,llm_int8_threshold=25.0,llm_int8_enable_fp32_cpu_offload=True)

model_catalog = {
    "Llama-3": {
        "id": "meta-llama/Meta-Llama-3-8B-Instruct",
        "model_kwargs": {
            #"quantization_config": quantization_config,
            #"low_cpu_mem_usage" : "True",
            "device_map":"auto"
        },
        "pipeline_kwargs": {
            "torch_dtype": torch.float16,  # bfloat16
            "max_new_tokens": 500,
        }         
    },
    "Llama-3.1": {
        "id": "meta-llama/Meta-Llama-3.1-8B-Instruct",
        "model_kwargs": {
            #"quantization_config": quantization_config,
            #"low_cpu_mem_usage" : "True",
            "device_map":"auto"
        },
        "pipeline_kwargs": {
            "top_p": 0.15,  
            "temperature": 0.7,
            "do_sample": True,  
            "torch_dtype": torch.float16,  # bfloat16
            "use_fast": True,
            "max_new_tokens": 500,
            "repetition_penalty": 1.1  # without this output begins repeating
        }   
    },
    "Mistral": {
        "id": "mistralai/Mistral-7B-Instruct-v0.1",
        "model_kwargs": {
            #"quantization_config": quantization_config,
            #"low_cpu_mem_usage" : "True",
            "device_map":"auto"
        },
        "pipeline_kwargs": {
            "temperature": 0.7,
            "do_sample": False,  # changed from true
            "max_new_tokens": 500,
            "repetition_penalty": 1.1  # without this output begins repeating
        }
    }     
}

# HF login and keys
api_key = None # insert your huggingface API key
if api_key is None:
    raise ValueError("You did not provide an API key (HF token). Please insert above.")
os.environ["HF_TOKEN"] = api_key 
os.environ["HUGGINGFACEHUB_API_TOKEN"] = api_key
from huggingface_hub import login
login(token = api_key)

# get model
model_name = "Mistral"
model = model_catalog[model_name]

llm = HuggingFacePipeline.from_model_id(
    model_id=model["id"],
    task="text-generation",
    pipeline_kwargs=model["pipeline_kwargs"],
    #device=0,
    **model["model_kwargs"]
)
if model_name == "Llama-3.1":
    llm.pipeline.tokenizer.pad_token_id = llm.pipeline.model.config.eos_token_id[0]
chat_model = ChatHuggingFace(llm=llm)


# setup tools
tools = load_tools(["wikipedia", "llm-math"], llm=llm)

tools += [
    PythonREPLTool(),
    Query2SMILES(),
    Query2CAS(),
    PatentCheck(),
    MolSimilarity(),
    SMILES2Weight(),
    FuncGroups(),
    ExplosiveCheck(),
    ControlChemCheck(),
    Scholar2ResultLLM(llm=llm),
    SafetySummary(llm=llm),
]

# # setup prompt
# prompt = hub.pull("hwchase17/react-json")
prompt = get_custom_prompt()

prompt = prompt.partial(
    tools=render_text_description(tools),
    tool_names=", ".join([t.name for t in tools]),
)

# define the agent
chat_model_with_stop = chat_model.bind(stop=["\nObservation"])
agent = (
    {
        "input": lambda x: x["input"],
        "agent_scratchpad": lambda x: format_log_to_str(x["intermediate_steps"]),
    }
    | prompt
    | chat_model_with_stop
    | ReActJsonSingleInputOutputParser()
)

# instantiate AgentExecutor
agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

agent_executor.invoke(
    {
        "input": "What is the SMILES string of ibuprofen?"
    }
)

agent_executor.invoke(
    {
        "input": "Can you find exemplary papers from the AVT.SVT in Aachen?"
    }
)
