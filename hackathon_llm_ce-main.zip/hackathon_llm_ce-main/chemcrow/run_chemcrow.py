from chemcrow.agents import ChemCrow

# required for running on HPC GPU 
# BATCH jobs: comment out
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1" 
os.environ["WORLD_SIZE"] = "1"

### These models are open-source but their intergration with chemcrow does not work properly
#api_key = None
#chem_model = ChemCrow(model_type="hf", model='mistralai/Mistral-7B-Instruct-v0.1', temp=0.7, max_tokens=4000, streaming=False, api_key=api_key) 
#chem_model = ChemCrow(model_type="hf", model='meta-llama/Meta-Llama-3-8B-Instruct', temp=0.7, max_tokens=4000, streaming=False, api_key=api_key) 
#chem_model = ChemCrow(model_type="hf", model="meta-llama/Meta-Llama-3.1-8B-Instruct", temp=0.7, max_tokens=500, streaming=False, api_key=api_key) 

### GPT-4 (OpenAI key is needed)
api_key = None
if api_key is None:
    raise ValueError("You did not provide an API key. Please insert above.")
chem_model = ChemCrow(
    model="gpt-4",
    temp=0.1,
    api_key=api_key,
    verbose=False
).agent_executor


chem_model.run("What is the SMILES of ibuprofen?")
